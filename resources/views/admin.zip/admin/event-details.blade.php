@extends('admin.layout.master')

@section('content')
	<div class="main">
		<div class="container">
			<div class="row">
				<div class="head head-on">
					<h4>Add Event</h4>
				</div>
				<div class="add-event">
					<form action="#" method="post">
						<div class="field-wrap">
							<div class="left">
								<label for="event-name">Event Name</label>
								<input type="text" id="event-name" name="event_name">
							</div>
							<div class="right">
								<label for="event-name-ar">اسم الحدث</label>
								<input type="text" id="event-name-ar" name="event_name_ar">
							</div>
						</div>
						<div class="field-wrap no-margin">
							<div class="left">
								<label>Images <i class="fa fa-plus-circle" aria-hidden="true"></i></label>
							</div>
							<div class="right">
								<label>صور</label>
							</div>
						</div>
						<div class="field-wrap">
							<ul class="img-list">
								<li><img src="{{URL::asset('public/admin/images/img1.jpg')}}" alt="image"></li>
								<li><img src="{{URL::asset('public/admin/images/img1.jpg')}}" alt="image"></li>
								<li><img src="{{URL::asset('public/admin/images/img1.jpg')}}" alt="image"></li>
								<li><img src="{{URL::asset('public/admin/images/img1.jpg')}}" alt="image"></li>
							</ul>
						</div>
						<div class="field-wrap">
							<div class="left">
								<label for="event-company">Organizer/Company Name</label>
								<input type="text" id="event-company" name="event_company">
							</div>
							<div class="right">
								<label for="event-company-ar">اسم الشركة</label>
								<input type="text" id="event-company-ar" name="event_company_ar">
							</div>
						</div>
						<div class="field-wrap">
							<div class="left">
								<div class="label-wrap">
									<label for="phone">Phone</label>
									<label for="phone">هاتف</label>
								</div>
								<input type="text" id="phone" name="phone">
							</div>
							<div class="right">
								<div class="label-wrap">
									<label for="email">Email</label>
									<label for="email">البريد الإلكتروني</label>
								</div>
								<input type="text" id="email" name="email">
							</div>
						</div>
						<div class="field-wrap">
							<div class="left">
								<div class="label-wrap">
									<label for="url">Web link</label>
									<label for="url">رابط موقع</label>
								</div>
								<input type="text" id="url" name="url">
							</div>
							<div class="right cal">
								<div class="start-date">
									<span>Start Date</span>
									<input type="text" placeholder="date" class="start-input">
									<input type="text" placeholder="time" class="timepicker">
								</div>
								<div class="end-date">
									<span>End Date</span>
									<input type="text" placeholder="date" class="end-input">
									<input type="text" placeholder="time" class="timepicker">
								</div>
							</div>
						</div>
						<div class="field-wrap">
							<div class="left">
								<h4>Locations: &nbsp;
&nbsp;
&nbsp;
&nbsp;
  مواقع</h4>
								<ul class="location-list">
									<li><a href="#add-location" class="add-location">Location1 &nbsp;
&nbsp;
&nbsp;
&nbsp;
 موقعك</a></li>
									<li><a href="#add-location" class="add-location">Location1 &nbsp;
&nbsp;
&nbsp;
&nbsp;
 موقعك</a></li>
									<li><a href="#add-location" class="add-location">Add More &nbsp;
&nbsp;
&nbsp;
&nbsp;
 أضف المزيد</a></li>
								</ul>
							</div>
							<div class="right left-right">
								<h4>All day event  &nbsp;
&nbsp;
&nbsp;
&nbsp;
&nbsp;
    كل حدث اليوم</h4>
								<div class="radio-wrap">
									<input type="checkbox" id="yes"><label for="yes">Yes   &nbsp;
&nbsp;
&nbsp;
  نعم </label>
								</div>
								<h4>Language of Event  &nbsp;
&nbsp;
&nbsp;
&nbsp;
&nbsp;
    لغة الحدث</h4>
								<div class="radio-wrap">
									<input type="radio" id="english" name="lang" value="en"><label for="english">English   &nbsp;
&nbsp;
&nbsp;
  الإنجليزية</label>
								</div>
								<div class="radio-wrap">
									<input type="radio" id="arabic" name="lang" value="ar"><label for="arabic">Arabic   &nbsp;
&nbsp;
&nbsp;
  عربى</label>
								</div>
							</div>
						</div>
						<div class="field-wrap">
							<div class="left">
								<label for="event-desc">Description</label>
								<textarea rows="6"></textarea>
							</div>
							<div class="right">
								<label for="event-desc-ar">وصف</label>
								<textarea rows="6"></textarea>
							</div>
						</div>
						<div class="field-wrap no-margin">
							<div class="left">
								<p>Attachments</p>
							</div>
							<div class="right">
								<p>المرفق</p>
							</div>
						</div>
						<div class="field-wrap">
							<ul class="img-list">
								<li><img src="{{URL::asset('public/admin/images/img1.jpg')}}" alt="image"></li>
								<li><img src="{{URL::asset('public/admin/images/img1.jpg')}}" alt="image"></li>
								<li><img src="{{URL::asset('public/admin/images/img1.jpg')}}" alt="image"></li>
								<li><img src="{{URL::asset('public/admin/images/img1.jpg')}}" alt="image"></li>
							</ul>
						</div>
						<div class="field-wrap">
							<h4>Venue  &nbsp;
&nbsp;
&nbsp;
&nbsp;
&nbsp;
    مكان</h4>
							<div class="radio-wrap">
								<input type="radio" id="venue" name="venue"><label for="men">Men   &nbsp;
&nbsp;
&nbsp;
  الذكر</label>
							</div>
							<div class="radio-wrap">
								<input type="radio" id="venue" name="venue"><label for="women">Women   &nbsp;
&nbsp;
&nbsp;
  إناثا</label>
							</div>
							<div class="radio-wrap">
								<input type="radio" id="venue" name="venue"><label for="separate">Separate Sitting   &nbsp;
&nbsp;
&nbsp;
  جلوس منفصلة</label>
							</div>
							<div class="radio-wrap">
								<input type="radio" id="venue" name="venue"><label for="public">Public   &nbsp;
&nbsp;
&nbsp;
  جلوس منفصلة</label>
							</div>
						</div>
						<div class="field-wrap">
							<div class="right">
								<input type="submit" value="Submit" class="btn-submit">
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
@endsection