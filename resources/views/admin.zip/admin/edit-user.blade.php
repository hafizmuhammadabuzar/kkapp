@extends('admin.layout.master')

@section('content')
    <div class="main">
        <div class="container">
            <div class="row">
                <div class="head head-on">
                    <h4>Edit User</h4>
                </div>
                <div class="add-event">
                    @include('partials.errors')
                    @include('partials.flash_messages')
                    <form action="{{ url('admin/update-user') }}" method="post" enctype="multipart/form-data">
                        {!! csrf_field() !!}
                        <div class="field-wrap">
                            <div class="left">
                                <label for="event-name">Username</label>
                                <input type="text" id="username" name="username" value="{{$user->username}}" required="required">
                            </div>
                        </div>
                        <div class="field-wrap">
                            <div class="left">
                                <label for="event-name">Email</label>
                                <input type="email" id="email" name="email" value="{{$user->email}}" required="required">
                            </div>
                        </div>
                        <div class="field-wrap">
                            <div class="left">
                                <label for="event-name-ar">Gender</label>
                                <input type="radio" id="gender" name="gender" value="Male" <?php if ($user->gender == 'Male') {echo 'checked="checked"';
}
?> required="required"> Male
                                <input type="radio" id="gender" name="gender" value="Female" <?php if ($user->gender == 'Female') {echo 'checked="checked"';
}
?> required="required"> Female
                            </div>
                        </div>
                        <div class="field-wrap">
                            <div class="left">
                                <label for="event-name">Date of Birth</label>
                                <input type="text" id="dob" name="dob" value="{{$user->dob}}" required="required">
                            </div>
                        </div>
                        <div class="field-wrap">
                            <div class="left">
                                <label for="event-name-ar">Picture</label>
                                <input type="file" id="picture" name="picture">
                                <img src="{{url('public/uploads/'.$user->image)}}" width="50" height="50"/>
                            </div>
                        </div>
                        <div class="field-wrap">
                            <div class="right">
                                <input type="hidden" name="user_id" id="user_id" value="{{Crypt::encrypt($user->id)}}">
                                <input type="hidden" name="old_picture" id="old_picture" value="{{$user->image}}">
                                <input type="submit" value="Submit" class="btn-submit">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection