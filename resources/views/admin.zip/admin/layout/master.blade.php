<?php
if (strpos($_SERVER['REQUEST_URI'], "view-categories") > 0 || strpos($_SERVER['REQUEST_URI'], "add-category") > 0 || strpos($_SERVER['REQUEST_URI'], "edit-category") > 0) {
	$category = 'class="active"';
} else if (strpos($_SERVER['REQUEST_URI'], "view-users") > 0 || strpos($_SERVER['REQUEST_URI'], "add-user") > 0 || strpos($_SERVER['REQUEST_URI'], "edit-user") > 0) {
	$user = 'class="active"';
} else if (strpos($_SERVER['REQUEST_URI'], "view-events") > 0 || strpos($_SERVER['REQUEST_URI'], "add-event") > 0 || strpos($_SERVER['REQUEST_URI'], "edit-event") > 0) {
	$user = 'class="active"';
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>KK App</title>
	<meta charset="utf-8">
	<meta name="author" content="Alpha Beta">
	<meta name="format-detection" content="telephone=no"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0"/>
	<!--	<link rel="shortcut icon" href="images/favicon.png">-->
	<link rel="stylesheet" href="{{ URL::asset('public/admin/css/font-awesome.min.css') }}">
	<link rel="stylesheet" href="{{ URL::asset('public/admin/css/bootstrap.min.css') }}">
	<link rel="stylesheet" href="{{ URL::asset('public/admin/css/jquery-ui.min.css') }}">
	<link rel="stylesheet" href="{{ URL::asset('public/admin/css/jquery.timepicker.min.css') }}">
	<link rel="stylesheet" href="{{ URL::asset('public/admin/css/animate.min.css') }}">
	<link rel="stylesheet" href="{{ URL::asset('public/admin/css/modal.css') }}">
	<link rel="stylesheet" href="{{ URL::asset('public/admin/css/style.css') }}">
	<script type="text/javascript" src="{{ URL::asset('public/admin/js/jquery-1.11.2.min.js') }}"></script>
	<script type="text/javascript" src="{{ URL::asset('public/admin/js/jquery-ui.min.js') }}"></script>
	<script type="text/javascript" src="{{ URL::asset('public/admin/js/jquery.timepicker.min.js') }}"></script>
	<script type="text/javascript" src="{{ URL::asset('public/admin/js/modal.js') }}"></script>
	<script type="text/javascript" src="{{ URL::asset('public/admin/js/all.js') }}"></script>
	<script type="text/javascript">
		$(document).ready(function(){
			$('.msg-success, .msg-error').fadeOut(3000);
		});
	</script>
	<style type="text/css">
		.add-btn{
			float: right;
			padding: 5px;
			border: 1px #81807e solid;
		}
	</style>
</head>
<body>
<div class="wrapper">
	<nav class="main-nav">
		<div class="container">
			<div class="row">
				<ul>
					<li><a href="index.php">Events</a></li>
					<li><a href="requests.php">Requests</a></li>
					<li <?php if (isset($user)) {echo $user;
}
?>><a href="{{url('admin/view-users')}}">Users</a></li>
					<li <?php if (isset($category)) {echo $category;
}
?>><a href="{{url('admin/view-categories')}}">Categories</a></li>
					<li><a href="push.php">Push Notifications</a></li>
					<li <?php if (isset($event)) {echo $event;
}
?>><a href="{{url('admin/add-event')}}">Add Event</a></li>
				</ul>
			</div>
		</div>
	</nav>

	@yield('content')

	<footer id="footer">
		<div class="container">
			<div class="row">
				<span class="copyright">&copy All Rights Reserved KK App <?php echo date('Y');?></span>
			</div>
		</div>
	</footer>
	<div id="add-location" style="display: none;">
		<form action="#" class="form-location">
			<div class="form-group">
				<label for="city">Select City</label>
				<input type="text" id="city" class="form-control">
			</div>
			<div class="form-group">
				<label for="event-location">Event Location</label>
				<input type="text" id="event-location" class="form-control">
			</div>
			<div class="g-map">
				<iframe src="//www.google.com/maps/embed/v1/place?q=Harrods,Brompton%20Rd,%20UK&zoom=17&key=YOUR_API_KEY"></iframe>
			</div>
			<div class="form-group">
				<input type="text" class="btn btn-info pull-right" value="Add Location">
			</div>
		</form>
	</div>
</div>
</body>
</html>