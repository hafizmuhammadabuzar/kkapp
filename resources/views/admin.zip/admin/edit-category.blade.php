@extends('admin.layout.master')

@section('content')
    <div class="main">
        <div class="container">
            <div class="row">
                <div class="head head-on">
                    <h4>Add Category</h4>
                </div>
                <div class="add-event">
                    @include('partials.errors')
                    @include('partials.flash_messages')
                    <form action="{{ url('admin/update-category') }}" method="post" enctype="multipart/form-data">
                        {!! csrf_field() !!}
                        <div class="field-wrap">
                            <div class="left">
                                <label for="event-name">Category</label>
                                <input type="text" id="english_category" name="english_category" value="{{$category->english}}" required="required">
                            </div>
                            <div class="right">
                                <label for="event-name-ar">الفئة</label>
                                <input type="text" id="arabic_category" name="arabic_category" value="{{$category->arabic}}" required="required">
                            </div>
                        </div>
                        <div class="field-wrap">
                            <div class="left">
                                <label for="event-name">Color</label>
                                <input type="text" id="color" name="color" value="{{$category->color}}" required="required">
                            </div>
                        </div>
                        <div class="field-wrap">
                            <div class="left">
                                <label for="event-name-ar">Icon</label>
                                <input type="file" id="icon" name="icon">
                                <img src="{{url('public/admin/icons/'.$category->icon)}}" width="50" height="50"/>
                            </div>
                        </div>
                        <div class="field-wrap">
                            <div class="right">
                                <input type="hidden" name="cat_id" id="cat_id" value="{{Crypt::encrypt($category->id)}}">
                                <input type="hidden" name="old_icon" id="old_icon" value="{{$category->icon}}">
                                <input type="submit" value="Update" class="btn-submit">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection